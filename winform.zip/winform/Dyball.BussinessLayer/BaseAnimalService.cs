﻿namespace Dyball.ServiceLayer
{
    public class BaseAnimalService
    {
        internal void Initialize(dynamic[] animalObject, int value = 0)
        {
            if (animalObject.Length > 0)
            {
                for (int i = 0; i < animalObject.Length; i++)
                {
                    if (animalObject[i].FeedValue < 100)
                    {
                        animalObject[i].FeedValue = animalObject[i].FeedValue - value;
                    }
                    if (animalObject[i].FeedValue > 100)
                    {
                        animalObject[i].FeedValue = 100;
                    }
                }
            }
        }
    }
}
