﻿using System;
using System.Windows.Forms;
using Dyball.ServiceLayer;


namespace winform
{
    public partial class Form1 : Form
    {
        private Timer _refreshTimer;
        private readonly AnimalService _service;

        public Form1()
        {
            _service = new AnimalService();

            InitializeComponent();
            InitialiseForm();

        }
        private void InitialiseForm()
        {
            _refreshTimer = new Timer
            {
                Interval = 10000
            };

            _refreshTimer.Tick += RefreshTimerTick;
            _refreshTimer.Start();
        }

        private void RefreshTimerTick(object sender, EventArgs e)
        {
            MessageBox.Show("Timer");
        }

        private void btnFeed_Click(object sender, EventArgs e)
        {
            _service.Feed();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dgElephant.DataSource = _service.Elephants;
            dgGiraffe.DataSource = _service.Giraffes;
            dgMonkey.DataSource = _service.Monkeys;
        }
    }
}
