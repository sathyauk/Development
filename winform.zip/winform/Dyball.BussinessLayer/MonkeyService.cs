﻿using Dyball.Domain;
using System;

namespace Dyball.ServiceLayer
{
    public class MonkeyService : IAnimal
    {

        public Monkey[] _monkeys = new Monkey[5] { new Monkey(), new Monkey(), new Monkey(), new Monkey(), new Monkey() };

        public Monkey[] Monkeys => _monkeys;

        private void InitializeMonkey(int value = 0)
        {
            for (int i = 0; i < _monkeys.Length; i++)
            {
                _monkeys[i].FeedValue = _monkeys[i].FeedValue - value;
            }
        }



        public bool CanWalk()
        {
            throw new NotImplementedException();
        }

        public void Feed(int value = 0)
        {
            InitializeMonkey(value);
        }

        public bool IsLive()
        {
            throw new NotImplementedException();
        }
    }
}
