﻿namespace Dyball.Domain
{
    public class Elephant : BaseAnimal
    {
        public Elephant()
        {
            FeedValue = 100;
        }
    }
}
