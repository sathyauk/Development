﻿
namespace Dyball.ServiceLayer
{
    public interface IAnimal
    {
        bool IsLive();
        bool CanWalk();
        void Feed(int value = 0);
    }
}
