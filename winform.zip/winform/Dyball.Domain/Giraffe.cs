﻿namespace Dyball.Domain
{
    public class Giraffe : BaseAnimal
    {
        public Giraffe()
        {
            FeedValue = 100;
        }
    }
}
