﻿
using Dyball.Domain;

namespace Dyball.ServiceLayer
{
    public class AnimalService
    {

        private readonly ElephantService _elephantService;
        private readonly GiraffeService _giraffeService;
        private readonly MonkeyService _monkeyService;

        public Elephant[] Elephants { get; set; }
        public Giraffe[] Giraffes { get; set; }
        public Monkey[] Monkeys { get; set; }


        public AnimalService()
        {
            _elephantService = new ElephantService();
            _giraffeService = new GiraffeService();
            _monkeyService = new MonkeyService();

            Initialize();
        }


        private void Initialize()
        {
            Elephants = _elephantService.Elephants;
            Giraffes = _giraffeService.Giraffes;
            Monkeys = _monkeyService.Monkeys;
        }

        public void Feed()
        {
            var random = new System.Random();
            var feedValue = random.Next(10, 25);

            _giraffeService.Feed(feedValue);

            feedValue = random.Next(10, 25);

            _elephantService.Feed(feedValue);

            feedValue = random.Next(10, 25);

            _monkeyService.Feed(feedValue);
        }
    }
}
