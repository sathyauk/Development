﻿using Dyball.Domain;
using System;
using System.Collections.Generic;
using System.Text;

namespace Dyball.ServiceLayer
{
    public class GiraffeService : IAnimal
    {

        public Giraffe[] _giraffes = new Giraffe[5] { new Giraffe(), new Giraffe(), new Giraffe(), new Giraffe(), new Giraffe() };

        public Giraffe[] Giraffes => _giraffes;


        private void InitializeGiraffe(int value = 0)
        {
            for (int i = 0; i < _giraffes.Length; i++)
            {
                if (_giraffes[i].FeedValue < 100)
                {
                    _giraffes[i].FeedValue = _giraffes[i].FeedValue + value;
                }

            }
        }

        public bool CanWalk()
        {
            throw new NotImplementedException();
        }

        public void Feed(int value = 0)
        {
            InitializeGiraffe(value);
        }

        public bool IsLive()
        {
            throw new NotImplementedException();
        }
    }
}
