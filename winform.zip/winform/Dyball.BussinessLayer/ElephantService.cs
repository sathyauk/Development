﻿using Dyball.Domain;
using System;
using System.Collections.Generic;
using System.Text;

namespace Dyball.ServiceLayer
{
    public class ElephantService : BaseAnimalService
    {
        
        public Elephant[] _elephants = new Elephant[5] { new Elephant(), new Elephant(), new Elephant(), new Elephant(), new Elephant() };

        public Elephant[] Elephants => _elephants;

        public ElephantService()
        {
            InitializeElephant();
        }

        private void InitializeElephant(int value = 0)
        {
            //for (int i = 0; i < _elephants.Length; i++)
            //{
            //    if (_elephants[i].FeedValue < 100)
            //    {
            //        _elephants[i].FeedValue = _elephants[i].FeedValue - value;
            //    }
            //    if (_elephants[i].FeedValue > 100)
            //    {
            //        _elephants[i].FeedValue = 100;
            //    }
            //}

            Initialize(Elephants, value);
        }

        public bool CanWalk()
        {
            throw new NotImplementedException();
        }

        
        public double Feed(int value)
        {
            InitializeElephant(value);
            return 0;
        }

        private void Live(double value)
        {

        }
    }
}
