﻿namespace Dyball.Domain
{
    public class Monkey : BaseAnimal
    {
        public Monkey()
        {
            FeedValue = 100;
        }
    }
}
